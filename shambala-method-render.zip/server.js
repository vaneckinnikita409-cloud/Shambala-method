const express=require("express"),multer=require("multer"),{spawn}=require("child_process"),fs=require("fs"),path=require("path");
const app=express();const upload=multer({dest:"uploads/",limits:{fileSize:500*1024*1024}});
app.use(express.static("."));
app.post("/process",upload.single("video"),(req,res)=>{
 if(!req.file)return res.status(400).send("No video");
 const input=req.file.path,output=path.join("uploads",Date.now()+"_shambala.mp4");
 // Automatic profile: preserve true source FPS up to 60, vertical 1080x1920,
 // H.264 CRF 18 with bitrate ceiling, 2s GOP, AAC 320k.
 const args=["-y","-i",input,"-vf","scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2:color=black,fps=min(source,60)","-c:v","libx264","-preset","slow","-crf","18","-maxrate","25M","-bufsize","50M","-pix_fmt","yuv420p","-profile:v","high","-level","4.2","-g","120","-keyint_min","120","-sc_threshold","0","-c:a","aac","-b:a","320k","-ar","48000","-movflags","+faststart",output];
 const p=spawn("ffmpeg",args);let err="";
 p.stderr.on("data",d=>err+=d.toString());
 p.on("error",e=>{fs.unlink(input,()=>{});res.status(500).send("FFmpeg not installed: "+e.message)});
 p.on("close",code=>{fs.unlink(input,()=>{});if(code!==0)return res.status(500).send("FFmpeg error: "+err.slice(-1000));res.download(output,"shambala_ready.mp4",()=>fs.unlink(output,()=>{}))});
});
app.listen(process.env.PORT || 3000,()=>console.log("Shambala Method running"));
