# Shambala Method — Render

## Deploy
1. Create a GitHub repository and upload all files from this ZIP.
2. In Render choose **New → Web Service** and connect the repository.
3. Choose the **Free** instance.
4. Because the repo contains a Dockerfile, Render builds the container with FFmpeg included.
5. Deploy and open the generated `onrender.com` URL.

The app listens on the PORT supplied by Render. Uploaded files are temporary and should not be treated as permanent storage.

## Local
npm install
npm start

Requires FFmpeg only if running without Docker.
